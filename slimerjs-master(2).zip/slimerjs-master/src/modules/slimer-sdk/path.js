
// Just a stub for the path module needed by CoffeeScript
