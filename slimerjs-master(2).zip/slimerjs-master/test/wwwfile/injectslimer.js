
injectedValue = "myvalue";

assertEquals("foo", ex.myExample, "value of ex.myExample inside injectslimer.js");

var newinjectedvalue = "yes!"