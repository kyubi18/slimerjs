function doInjectError() {
    throw new Error("error from injectdoerror.js")
}

doInjectError();
