'use strict';

// This test make sure that console.log can take multiple arguments

// TODO ? Compare the output of console.log()
// with one argument vs multiple arguments.

console.log('A ' + 'B ' + 'C');
console.log('A', 'B', 'C');

slimer.exit();
