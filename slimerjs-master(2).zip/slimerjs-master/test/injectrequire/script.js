
var requireIntoInjectedScript = require('./somemodules/myinclude.js');

console.log(requireIntoInjectedScript.myinclude);
