var c = require('../module_c');

exports.result = "loaded "+c.hello;