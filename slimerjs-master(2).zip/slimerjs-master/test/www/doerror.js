function arrrrrg() {
    throw new Error("error from doerror.js")
}

arrrrrg();
