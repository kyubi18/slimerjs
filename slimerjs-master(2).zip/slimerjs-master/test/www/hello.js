var foo=4;

document.write('<p>script</p>');

var xhr = new XMLHttpRequest();
xhr.open('GET', 'hello.txt', true);
xhr.send();