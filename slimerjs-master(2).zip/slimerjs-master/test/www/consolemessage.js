window.onload = function(event){
    console.log('message from consolemessagejs')
}