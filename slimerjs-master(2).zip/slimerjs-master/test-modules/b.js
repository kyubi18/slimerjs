var c = require('./c');

exports.bIsLoaded = 'yes'

exports.cIsLoaded = c.cIsLoaded;

exports.idName = c.identity.firstName