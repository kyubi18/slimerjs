
### versions 

- SlimerJS: 
- Firefox: 
- Operating system: 

### Steps to reproduce the issue


### Actual results:


### Expected results:


